create definer = root@localhost view tl1 as
select 1 AS `id`, 1 AS `time`;

