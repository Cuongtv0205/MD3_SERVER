create definer = root@localhost view top3p as
select `qlsv_qlbh`.`product`.`price` AS `price`
from `qlsv_qlbh`.`product`
group by `qlsv_qlbh`.`product`.`price`
order by `qlsv_qlbh`.`product`.`price` desc
limit 3;

