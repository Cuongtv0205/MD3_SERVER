create definer = root@localhost view tl as
select 1 AS `id`, 1 AS `time`;

