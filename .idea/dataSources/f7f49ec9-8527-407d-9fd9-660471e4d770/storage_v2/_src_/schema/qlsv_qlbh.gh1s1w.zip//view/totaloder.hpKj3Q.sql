create definer = root@localhost view totaloder as
select `qlsv_qlbh`.`order`.`id` AS `id`, sum(`p`.`price`) AS `Total`
from ((`qlsv_qlbh`.`order` join `qlsv_qlbh`.`orderdetail` `od`
       on ((`qlsv_qlbh`.`order`.`id` = `od`.`orderId`))) join `qlsv_qlbh`.`product` `p`
      on ((`od`.`productId` = `p`.`id`)))
where (year(`qlsv_qlbh`.`order`.`time`) = 2006)
group by `qlsv_qlbh`.`order`.`id`;

