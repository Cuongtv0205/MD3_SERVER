create definer = root@localhost view caltotaloforder as
select `qlsv_qlbh`.`order`.`id` AS `id`, sum((`p`.`price` * `o`.`quantity`)) AS `Total`
from ((`qlsv_qlbh`.`order` join `qlsv_qlbh`.`orderdetail` `o`
       on ((`qlsv_qlbh`.`order`.`id` = `o`.`orderId`))) join `qlsv_qlbh`.`product` `p`
      on ((`p`.`id` = `o`.`productId`)))
group by `qlsv_qlbh`.`order`.`id`;

