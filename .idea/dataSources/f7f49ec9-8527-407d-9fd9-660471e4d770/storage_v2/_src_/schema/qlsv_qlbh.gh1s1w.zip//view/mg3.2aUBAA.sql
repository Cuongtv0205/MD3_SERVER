create definer = root@localhost view mg3 as
select `o`.`id` AS `id`, `o`.`time` AS `time`
from ((`qlsv_qlbh`.`orderdetail` `od` join `qlsv_qlbh`.`product` `p`) join `qlsv_qlbh`.`order` `o`)
where ((`od`.`productId` = `p`.`id`) and (`o`.`id` = `od`.`orderId`) and (`p`.`name` like 'Máy Giặt') and
       (`od`.`quantity` >= 10) and (`od`.`quantity` <= 20));

